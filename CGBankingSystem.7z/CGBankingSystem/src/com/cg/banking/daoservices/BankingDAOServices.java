package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public interface BankingDAOServices {
	int insertCustomer(Customer customer)throws SQLException;
	int insertAccount(Account account)throws SQLException;
	int generatePin(Account account)throws SQLException;
	boolean updateAccount(int customerId,Account account)throws SQLException;
	boolean insertTransaction(int customerId,int accountNo,Transaction transaction)throws SQLException;
	boolean deleteCustomer(int customerId)throws SQLException;
	boolean deleteAccount(int customerId,int accountNo)throws SQLException;
	Customer getCustomer(int customerId)throws SQLException;
	Account getAccount(int customerId,int accountNo)throws SQLException;
	List<Customer> getCustomers()throws SQLException;
	List<Account> getAccounts(int customerId)throws SQLException;
	List<Transaction> getTransaction(int accountNo)throws SQLException;
	
}

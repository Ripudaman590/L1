package com.cg.obs.dao;

public interface IQueryMapper {

	public static final String LOCK_QRY = "UPDATE USERS SET LockStatus=? where UserId=?";
	public static final String LOGIN_QRY=
			"SELECT customerId,UserId,LoginPassword,SecretQuestion,Answer,TransactionPassword,"
					+ " LockStatus FROM USERS WHERE UserId=?";
	public static final String UPDATE_USER_SECURITY = "UPDATE USERS SET SecretQuestion=?,Answer=? WHERE UserId=?";
	
	//ADmin Queries
	public static final String INSERT_ACCOUNT_QRY=
			"INSERT INTO ACCOUNTMASTER(AccountId,AccountType,AccountBalance,OpenDate) "
			+ "values(account_id_seq.nextVal,?,?,?)";
	public static final String INSERT_CUSTOMER_QRY=
			"INSERT INTO CUSTOMER(customerId,CustomerName,Email,Address,Pancard,Mobile)"
			+ "values(customer_id_seq.nextval,?,?,?,?,?)";
	public static final String INSERT_CUST_ACC=
			"INSERT INTO CUSTOMERACCOUNT(customerId,AccountId) values (customer_id_seq.currval,account_id_seq.currVal)";
	public static final String SELECT_ACCOUNT_ID_QRY=
			"SELECT account_id_seq.currval FROM DUAL";
	public static final String INSERT_USER_QRY=
			"INSERT INTO USERS(customerId,UserId,LoginPassword,SecretQuestion,"
			+ "Answer,TransactionPassword,LockStatus) values"
			+ "(customer_id_seq.currval,user_id_seq.nextval,login_pwd_seq.nextval,"
			+ "'null','null',trans_pwd_seq.nextval,'F')";
	public static final String SELECT_USER_CRED_QRY=
			"SELECT * FROM USERS WHERE AccountId=?";
	public static final String GET_ACCOUNT_QRY ="SELECT AccountId, AccountType, AccountBalance, openDate from AccountMaster where AccountId=? ";
	public static final String GET_ACCOUNTID_QRY = "SELECT AccountId FROM customerAccount where customerId=?";
	public static final String GET_CUSTOMER_QRY = "SELECT customerId,CustomerName,Email,Address,Pancard,Mobile FROM CUSTOMER where customerId=? ";
	public static final String GET_MINISTATEMENT = "SELECT TransactionId,DateofTransaction,"
			+ "TranAmount FROM Transactions WHERE AccountId=?";
	public static final String GET_TRANSACTION = "SELECT TransactionId,Description,DateofTransaction,"
			+ "TransactionType,TranAmount,AccountId FROM Transactions WHERE DateofTransaction BETWEEN ? AND ?";
	public static final String INSERT_SERVICE_CHQ = "INSERT INTO ServiceTracker VALUES(service_id_seq.NEXTVAL,'Cheque Book Request',?,sysdate,'pending')";
	public static final String CHANGE_PASSWORD = "UPDATE USERS SET LOGINPASSWORD=? where USERID=?";
	public static final String UPDATE_DETAILS_QRY = "UPDATE Customer SET Address=?,Mobile=? WHERE CustomerId=?";

    public static final String UPDATE_FROMACCBALANCE_QRY="UPDATE accountmaster set accountbalance=accountbalance-? where accountid=?";
    
    public static final String UPDATE_TOACCBALANCE_QRY="UPDATE accountmaster set accountbalance=accountbalance+? where accountid=?";
}

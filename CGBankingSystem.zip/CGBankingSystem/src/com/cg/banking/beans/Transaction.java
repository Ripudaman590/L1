package com.cg.banking.beans;
public class Transaction {
	private int transactionId;
	private float amount;
	private String transactionType;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, float amount, String transactionType) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactionType = transactionType;
	}
	
}
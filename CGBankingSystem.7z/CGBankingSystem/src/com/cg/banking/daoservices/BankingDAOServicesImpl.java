package com.cg.banking.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
public class BankingDAOServicesImpl implements BankingDAOServices {

	@Override
	public int insertCustomer(Customer customer) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertAccount(Account account) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int generatePin(Account account) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean insertTransaction(int customerId, int accountNo, Transaction transaction) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, int accountNo) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, int accountNo) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) throws SQLException {
		
		return null;
	}

	@Override
	public List<Transaction> getTransaction(int accountNo) throws SQLException {
	
		return null;
	}



}

package com.cg.obs.dto;

public class UserBean {
	
		private int userId;
		private String customerId;
		private String loginPassword;
		private String transactionPassword;
		private String question;
		private String answer;
		private char lockStatus;
		public UserBean(){
			
		}
		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}
		public String getLoginPassword() {
			return loginPassword;
		}
		public void setLoginPassword(String loginPassword) {
			this.loginPassword = loginPassword;
		}
		public String getTransactionPassword() {
			return transactionPassword;
		}
		public void setTransactionPassword(String transactionPassword) {
			this.transactionPassword = transactionPassword;
		}
		public String getQuestion() {
			return question;
		}
		public void setQuestion(String question) {
			this.question = question;
		}
		public String getAnswer() {
			return answer;
		}
		public void setAnswer(String answer) {
			this.answer = answer;
		}	
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
	
	
		public char getLockStatus() {
			return lockStatus;
		}
		public void setLockStatus(char lockStatus) {
			this.lockStatus = lockStatus;
		}
}

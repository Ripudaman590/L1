package com.cg.obs.dto;

import java.util.List;

public class CustomerBean {
	
		private String customerId;	
		private String customerName;
		private String email;
		private String address;
		private String pancard;
		private String mobile;
		private List<AccountBean> accounts;
				
		public CustomerBean() {		
	
		}
		public String getCustomerId() {
			return customerId;
		}
		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getPancard() {
			return pancard;
		}
		public void setPancard(String pancard) {
			this.pancard = pancard;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public List<AccountBean> getAccounts() {
			return accounts;
		}
		public void setAccounts(List<AccountBean> accounts) {
			this.accounts = accounts;
		}
	
		
		
}

create table AccountMaster( 
AccountId NUMBER(10)Primary key,
AccountType VARCHAR2(25) not null,
AccountBalance NUMBER(15) not null,
OpenDate DATE not null);

create sequence account_id_seq
start with 1012100000
increment by 1;

create table Customer(
CustomerId number(10) not null primary key,
CustomerName VARCHAR2(50) not null,
Email VARCHAR2(30) not null, 
Address VARCHAR2(100)not null,
Mobile NUMBER(10) not null,
Pancard VARCHAR2(15) unique not null);

create sequence customer_id_seq
start with 1002003000
increment by 1;

create table customerAccount(
CustomerId number(10) References Customer(CustomerId),
AccountId number(10) References AccountMaster(AccountId) primary key
);

create table Users(
CustomerId number(10) References Customer(CustomerId),
UserId NUMBER primary key,
LoginPassword VARCHAR2(15)not null ,
SecretQuestion VARCHAR2(50)not null,
Answer VARCHAR2(50)not null,
TransactionPassword VARCHAR2(15)not null,
LockStatus VARCHAR2(1) not null);



create table Transactions(
TransactionId NUMBER primary key ,
Description VARCHAR2(100)not null,
DateofTransaction DATE not null,
TransactionType VARCHAR2(1)not null,
TranAmount NUMBER(15)not null ,
AccountId NUMBER(10) References AccountMaster(AccountId));

create table ServiceTracker(
ServiceId NUMBER primary key,
ServiceDescription VARCHAR2(100)not null,
AccountId NUMBER references AccountMaster(AccountId),
ServiceRaisedDate DATE not null,
ServiceStatus VARCHAR2(20) not null);


create sequence user_id_seq
start with 10000
increment by 1;

create sequence login_pwd_seq
start with 250162
increment by 1;
create sequence trans_pwd_seq
start with 150260
increment by 1;



create table FundTransfer( 
FundTransferId NUMBER primary Key,
AccountId NUMBER(10) references AccountMaster(AccountId) ,
PayeeAccountId NUMBER(10)references AccountMaster(AccountId) ,
DateOfTransfer DATE not null,
TransferAmount NUMBER(15)not null);


create table PayeeTable(
AccountId NUMBER references AccountMaster(AccountId),
PayeeAccountId NUMBER references AccountMaster(AccountId),
NickName VARCHAR2(40)not null);

create sequence service_id_seq
start with 100
increment by 1; 

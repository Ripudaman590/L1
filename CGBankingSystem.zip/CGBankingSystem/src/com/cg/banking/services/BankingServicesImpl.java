package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
public class BankingServicesImpl implements BankingServices {

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			int homeAddressPinCode, String homeAddressCity, String homeAddressState, int localAddressPinCode,
			String localAddressCity, String localAddressState) throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int openAccount(int accountBalance, String accountType) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float depositAmount(int customerId, int accountNo, float amount) throws CustomerNotFoundException,
			AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, int accountNoTo, int customerIdFrom, int accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateCustomerAccountNewPin(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean changeCustomerAccountPin(int customerId, int accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getCustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomeAccountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}

package com.cg.banking.beans;
public class Address {
	private int pincode;
	private String city,state; 	
}
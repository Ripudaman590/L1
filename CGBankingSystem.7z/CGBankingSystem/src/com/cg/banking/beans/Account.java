package com.cg.banking.beans;

import java.util.HashMap;
import java.util.Map;

public class Account {

	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int pinNumber;
	private String status;
	private int pinCounter;
	private Map<Integer, Transaction>transactions=new HashMap<Integer, Transaction>();
	
	
}

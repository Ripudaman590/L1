package com.cg.banking.beans;

import java.util.HashMap;
import java.util.Map;

public class Account {

	private int accountNo;
	private String accountType;
	private float accountBalance;
	private int pinNumber;
	private String status;
	private int pinCounter;
//	private Map<Integer, Transaction>transactions=new HashMap<Integer, Transaction>();
	public  static HashMap<Integer, Transaction> transactions = new HashMap<>();
	public static int TRANSACTIONS_ID_COUNTER =100;
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance
				+ ", pinNumber=" + pinNumber + ", status=" + status
				+ ", pinCounter=" + pinCounter + ", transactions="
				+ transactions + "]";
	}
	public Account(int accountNo, String accountType, float accountBalance,
			int pinNumber, String status, int pinCounter,
			Map<Integer, Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.pinNumber = pinNumber;
		this.status = status;
		this.pinCounter = pinCounter;
		this.transactions = (HashMap<Integer, Transaction>) transactions;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(accountBalance);
		result = prime * result + accountNo;
		result = prime * result
				+ ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + pinCounter;
		result = prime * result + pinNumber;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result
				+ ((transactions == null) ? 0 : transactions.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (Float.floatToIntBits(accountBalance) != Float
				.floatToIntBits(other.accountBalance))
			return false;
		if (accountNo != other.accountNo)
			return false;
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (pinCounter != other.pinCounter)
			return false;
		if (pinNumber != other.pinNumber)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (transactions == null) {
			if (other.transactions != null)
				return false;
		} else if (!transactions.equals(other.transactions))
			return false;
		return true;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accountNo2, String accountType2, int accountBalance2,
			int pinNumber2, String status2, int pinCounter2,
			Transaction transaction) {
		// TODO Auto-generated constructor stub
	}
	public Account(int i, String string, int j, int k, String string2, int l) {
		// TODO Auto-generated constructor stub
	}
	
	
}

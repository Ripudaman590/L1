package com.cg.obs.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.obs.dao.IOnlineBankingDao;
import com.cg.obs.dao.OnlineBankingDaoImpl;
import com.cg.obs.dto.AccountBean;
import com.cg.obs.dto.CustomerBean;
import com.cg.obs.dto.ServiceTracker;
import com.cg.obs.dto.TransactionBean;
import com.cg.obs.dto.UserBean;
import com.cg.obs.exception.BankingException;

public class OnlineBankingServiceImpl implements IOnlineBankingService {
	private IOnlineBankingDao bankingDao;
	
	public OnlineBankingServiceImpl()throws BankingException {
		bankingDao= new OnlineBankingDaoImpl(); 
	}
	@Override
	public UserBean userLogin(int userId)throws BankingException {
		return bankingDao.userLogin(userId);}
	
	@Override
	public boolean setUserSecurity(UserBean userBean) throws BankingException {
		return bankingDao.setUserSecurity(userBean);
	}
	
	
	@Override
	public List<AccountBean> addAccount(CustomerBean customer) throws BankingException {		
		List<AccountBean> accountList=null;	
		CustomerBean customerBean=addCustomer(customer);
		if(customerBean!=null){			
			accountList= bankingDao.addAccount(customer);
			if(accountList!=null){
				boolean generateUser=setUserCredentials();
					if(!generateUser)
						throw new BankingException("Unable to Generate User Credentials.");
				}
		}
		return accountList;
	}
	@Override
	public boolean setUserCredentials() throws BankingException {
		return bankingDao.setUserCredentials();
	}
	@Override
	public boolean lockUser(int userId) throws BankingException {
		return bankingDao.lockUser(userId);
	}
	@Override
	public UserBean getUserCredentials(String accountId)
			throws BankingException {
		return bankingDao.getUserCredentials(accountId);
	}
	
	@Override
	public CustomerBean addCustomer(CustomerBean customer)
			throws BankingException {
		return bankingDao.addCustomer(customer);
	}
	
	//new
	@Override
	public List<TransactionBean> getMiniStatementsById(String accountId) throws BankingException{
		return bankingDao.getMiniStatementsById(accountId);
	}
	@Override
	public CustomerBean getCustomerDetails(int customerId)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getCustomerDetails(customerId);
	}
	@Override
	public Integer[] getAccountId(String customerId) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getAccountId(customerId);
	}
	@Override
	public AccountBean getAccountDetails(int accountId) throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.getAccountDetails(accountId);
	}
	
	//new
	@Override
	public List<TransactionBean> getTransactionByAccId(String from, String to) throws BankingException{
		// TODO Auto-generated method stub
		return bankingDao.getTransactionByAccId(from,to);
	}
	
//new
	@Override
	public boolean requestChequeBook(String accountId)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.requestChequeBook(accountId);
	}
	
	@Override
	public boolean changePassword(String userId, String newPassword) 
			throws BankingException {
		
		return bankingDao.changePassword( userId, newPassword);
	}

	//new
	@Override
	public boolean updateDetails(CustomerBean customerBean) throws BankingException {
		return bankingDao.updateDetails(customerBean);
	}
	@Override
	public ServiceTracker requestStatus(String serviceRequestId)
			throws BankingException {
		// TODO Auto-generated method stub
		return bankingDao.requestStatus(serviceRequestId);
	}
	@Override
	public boolean updateAccBalance(double transAmount, String accountId)
			throws BankingException {
		
		return bankingDao.updateAccBalance( transAmount, accountId);
		
	}
	
}

package com.cg.obs.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.obs.dto.AccountBean;
import com.cg.obs.dto.CustomerBean;
import com.cg.obs.dto.ServiceTracker;
import com.cg.obs.dto.TransactionBean;
import com.cg.obs.dto.UserBean;
import com.cg.obs.exception.BankingException;

public interface IOnlineBankingService {
	
	 public abstract UserBean userLogin(int userId)throws BankingException;
	 boolean lockUser(int userId) throws BankingException;
	public abstract boolean setUserSecurity(UserBean userBean) throws BankingException;
	
	//new
	CustomerBean getCustomerDetails(int customerId) throws BankingException;
	Integer[] getAccountId(String customerId) throws BankingException;
	AccountBean getAccountDetails(int accountId) throws BankingException;
	 /*
	  * admin functionalities 
	  */
	 public CustomerBean addCustomer(CustomerBean customer) throws BankingException;
	 public List<AccountBean> addAccount(CustomerBean customer) throws BankingException;
	 public boolean setUserCredentials() throws BankingException;
	 public UserBean getUserCredentials(String customerId) throws BankingException;
	List<TransactionBean> getMiniStatementsById(String accountId)throws BankingException;
	
	boolean requestChequeBook(String accountId) throws BankingException;
	boolean changePassword(String userId, String newPassword)
			throws BankingException;
	boolean updateDetails(CustomerBean customerBean) throws BankingException;
	List<TransactionBean> getTransactionByAccId(String from, String to)
			throws BankingException;
    
	boolean updateAccBalance(double transAmount, String accountId) throws BankingException;
	
public ServiceTracker requestStatus(String serviceRequestId) throws BankingException;
}

package com.cg.banking.beans;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Customer {
	
	private int customerId;
	private String firstName,lastName,emailId,panCard;
	private String password;
	private List<Address>addresses;
	Map<Integer, Account> accounts=new HashMap<>();

	
}

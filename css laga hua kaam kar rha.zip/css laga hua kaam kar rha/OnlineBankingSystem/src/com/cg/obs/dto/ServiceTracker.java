package com.cg.obs.dto;

public class ServiceTracker {
		
	private String serviceId;
	private String description;
	private String raise;
	private String status;
	
	//new
	private String AccountId;
	
	public String getAccountId() {
		return AccountId;
	}
	public void setAccountId(String accountId) {
		AccountId = accountId;
	}
	public ServiceTracker(){
	}	
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRaise() {
		return raise;
	}
	public void setRaise(String raise) {
		this.raise = raise;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}

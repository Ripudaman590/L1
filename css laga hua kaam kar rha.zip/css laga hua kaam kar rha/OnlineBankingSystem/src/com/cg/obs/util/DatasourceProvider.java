package com.cg.obs.util;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.obs.exception.BankingException;

public class DatasourceProvider {

	private static DatasourceProvider dsp;

	private DataSource dataSource;

	private DatasourceProvider() throws BankingException {
		try {
			InitialContext context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:/jdbc/MyDS");
		} catch (NamingException exp) {
			throw new BankingException(exp.getMessage());
		}
	}

	public static synchronized DatasourceProvider getDatasourceProvider()
			throws BankingException {
		if (dsp == null)
			dsp = new DatasourceProvider();
		return dsp;
	}
	
	public DataSource getDataSource(){
		return this.dataSource;
	}
}

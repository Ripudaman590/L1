package com.cg.obs.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

















import sun.swing.BakedArrayList;

import com.cg.obs.dto.AccountBean;
import com.cg.obs.dto.CustomerBean;
import com.cg.obs.dto.FundTransferBean;
import com.cg.obs.dto.ServiceTracker;
import com.cg.obs.dto.TransactionBean;
import com.cg.obs.dto.UserBean;
import com.cg.obs.exception.BankingException;
import com.cg.obs.service.IOnlineBankingService;
import com.cg.obs.service.OnlineBankingServiceImpl;

/**
 * Servlet implementation class BankingController
 */
@WebServlet("*.obj")
public class BankingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IOnlineBankingService bankingService;
	Logger logger;
	UserBean userBean=null;
	TransactionBean transactionBean=null;
	AccountBean accountBean=null;
	
	public void init() {
		String logPropertiesFilePath = "/WEB-INF/log4j.properties";
		logPropertiesFilePath = getServletContext().getRealPath(
				logPropertiesFilePath);
		PropertyConfigurator.configure(logPropertiesFilePath);
		logger = Logger.getLogger("BankingController");
		try {
			bankingService=new OnlineBankingServiceImpl();
		} catch (BankingException exp) {
			System.out.println(exp.getMessage());
			logger.error(exp);
		}
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");		
		String path = request.getServletPath();
		String view = "";	
		
		switch (path) {
		case "/miniStatement.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				view="Pages/miniStatement.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
		case "/index.obj":
				try{
					if(bankingService==null)
						throw new BankingException("DB not Ready");	
					request.setAttribute("attempts",3);
					view="Pages/Login.jsp";
					
				}catch(BankingException exp){
					logger.error(exp);				
					request.setAttribute("msg", exp.getMessage());
					view = "Pages/ErrorPage.jsp";
				}
			break;
			
		case "/toLogin.obj":
			view="Pages/Login.jsp";
			break;
			
		case "/toIndex.obj":
			view="Pages/IndexPage.jsp";
			break;
			
		case "/toContactUs.obj":
			view="Pages/ContactUsPage.jsp";
			break;
			
		case "/login.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				
				String password = request.getParameter("password");
				
				// Admin check
				if(request.getParameter("userId").equalsIgnoreCase("Admin") ){
					if(password.equalsIgnoreCase("Admin")){ 
						view="Pages/Admin.jsp";
						HttpSession session=request.getSession(true);
						//session for 1 minute
						session.setAttribute("user", "Admin");
						session.setMaxInactiveInterval(30);
					}else{
						request.setAttribute("attempts", 3);
					request.setAttribute("msg","Invalid Username");
					view="Pages/Login.jsp";}
				}
				else{
					int userId = Integer.parseInt(request.getParameter("userId"));					
					userBean=bankingService.userLogin(userId);
					System.out.println(userId);					
					if(userBean==null){
						request.setAttribute("attempts", 3);
						request.setAttribute("msg","Invalid Username");
						view="Pages/Login.jsp";
					}		
					else if(userBean.getLockStatus()!='T'){
					if(userBean.getLoginPassword().equals(password)){
						HttpSession session=request.getSession(true);
						//session for 1 minute
						session.setAttribute("user", userBean.getUserId());
						session.setMaxInactiveInterval(60*3);
						if(userBean.getQuestion().equalsIgnoreCase("null"))
							view="Pages/SetSecurityQuestion.jsp";
						else
							view="Home.obj";						
					}
					else{
						int attempt=Integer.parseInt(request.getParameter("attempts"))-1;
						if(attempt>0)
						{  request.setAttribute("msg","Invalid Password");
							view="Pages/Login.jsp";
							request.setAttribute("attempts", attempt);
							
						}
						else
						{								
							if(bankingService.lockUser(userId)){
								request.setAttribute("msg", "Your Online Banking account has been locked due to too many failed login attempts");
								view="Pages/SecurityQuestion.jsp";
							}
							else{
								view="Pages/ErrorPage.jsp";
								request.setAttribute("msg"," Contact Your nearby Branch" );
							}
								
						}
					}
						
					}
					else{
						request.setAttribute("msg", "Your Account has been locked");
						view="Pages/SecurityQuestion.jsp";
					}
				}
					
										
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}catch(NullPointerException exp ){
				view = "Pages/Login.jsp";
			}
		break;			
		
		case "/logOut.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");	
				request.setAttribute("attempts",3);
				HttpSession session=request.getSession(false);
				if(session != null){
			    		session.invalidate();
			    	}  
				view="Pages/Login.jsp";
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
		break;
		
		case "/fundTransfer.obj":
			view="Pages/FundTransfer.jsp";
		break;
		
		case "/otherAccounts.obj":
			view="Pages/OthersFundTransfer.jsp";
			break;
	
		case "/addPayee.obj":
			
			view="Pages/AddPayee.jsp";
			break;
			

		case "/finalFundTransfer.obj":
			view="Pages/FinalFundTransfer.jsp";
			break;
			
		case "/TransferFund.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				
				String transPassword = request.getParameter("transactionPassword");
				
				TransactionBean fund=new TransactionBean();
				fund.setTransactionAmount(Double.parseDouble(request.getParameter("transAmount")));
				if(userBean.getTransactionPassword().equals(transPassword))
				{
					HttpSession session=request.getSession(true);
					session.setAttribute("accountId", accountBean.getAccountId());
					
					bankingService.updateAccBalance(fund.getTransactionAmount(), accountBean.getAccountId());
					view="Pages/TransferSuccess.jsp";
				}
				else{
					request.setAttribute("msg","Unable to Transer Fund");
					view="Pages/FinalFundTransfer.jsp";
				}
			
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			
			break;
			
		
		case "/SetSecurityQues.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				else {
					String question=request.getParameter("SecurityQuestion");
					String answer=request.getParameter("answer");
					if(!question.isEmpty() && !answer.isEmpty()){
						userBean.setQuestion(question);
						userBean.setAnswer(answer);
						if(bankingService.setUserSecurity(userBean)){
							request.setAttribute("msg", "Security successfuly Set");
							view="Pages/Success.jsp";
						}
					}
				}
				view="Home.obj";
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}			
			break;
		//new	
		case "/mini.obj":
			
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				else {
					List<TransactionBean> transactions=new ArrayList<TransactionBean>();
					transactions=bankingService.getMiniStatementsById(request.getParameter("accountId"));
					request.setAttribute("transactions",transactions);
				}				
				view="/Pages/miniStatement.jsp";
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}			
			break;
			
			//new
		case "/detailedTransaction.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				view="Pages/Transaction.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			//new
		  case "/viewTransaction.obj":
			
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				else {
					List<TransactionBean> transactions=new ArrayList<TransactionBean>();
					transactions=bankingService.getTransactionByAccId(request.getParameter("from"),request.getParameter("to"));
					request.setAttribute("transactions",transactions);
								
				/*request.setAttribute("accountId",request.getParameter("accountId"));
				request.setAttribute("from",request.getParameter("from"));
				request.setAttribute("to",request.getParameter("to"));*/
				view="Pages/ViewTransaction.jsp";
				}
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}			
			break;
			
		case "/transaction.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				/*else {
					HttpSession session=request.getSession();
					TransactionBean transactionBean=new TransactionBean();
					String id=transactionBean.getAccountId();
				}*/			
				view="Pages/ViewTransaction.jsp";
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}			
			break;
			
			//new
			
		case "/Home.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");	
				HttpSession session=request.getSession();
				CustomerBean customerBean=bankingService.getCustomerDetails(Integer.parseInt(userBean.getCustomerId()));
				session.setAttribute("customer", customerBean);
				view="Pages/Home.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
		case "/chequeBookRequest.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				view="Pages/chequeBookRequest.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			

		case "/getServiceRequestStatus1.obj":
			view="Pages/TrackServiceRequest.jsp";
			break;
			
		case "/getServiceRequestStatus.obj" :
			try
			{	
				if(bankingService==null)
						throw new BankingException("DB not Ready");
				ServiceTracker myServiceTracker = bankingService.requestStatus(request.getParameter("serviceId"));
				if(myServiceTracker!=null)
				{
					String status = myServiceTracker.getStatus();
					System.out.println(status);
					HttpSession session  = request.getSession();
					session.setAttribute("status",status);
					System.out.println("Chal Raha hai! :)");
					view="Pages/Success.jsp";
				}
				else
				{
					System.err.println("value not coming from database");
				}
			}
			catch(BankingException e)
			{
					logger.error(e);
					request.setAttribute("msg",e.getMessage());
					view="ErrorPage.jsp";
				}
			break;
			
			
			
		//new	
		case "/createChequeBookRequest.obj":
			
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");	
				if(request.getParameter("accountId")!=null){
					bankingService.requestChequeBook(request.getParameter("accountId"));
					request.setAttribute("msg","Cheque Book Request Successfuly generated for Account Id : "+request.getParameter("accountId"));
				}
				else{
					request.setAttribute("msg","Unable to generate request");
				}
				view="Pages/chequeBookRequest.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			
		case "/changePassword.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");	
				if(request.getParameter("userId")!=null){
					bankingService.changePassword(request.getParameter("userId"),request.getParameter("newPassword"));
					request.setAttribute("msg","Password Changed for User Id : "+request.getParameter("userId")+"<br/> Login Again with new Password!");
					HttpSession session=request.getSession();
					session.removeAttribute("user");
					session.removeAttribute("customer");
					session.invalidate();
					view="Pages/Login.jsp";
				}
				else{
					request.setAttribute("msg","Unable to Change Password");
					view="Pages/NewPassword.jsp";
				}
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			
		case "/changeNewPassword.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				view="Pages/NewPassword.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			
			//new
		case "/update.obj":
			try {
				if (bankingService == null) {
					throw new BankingException("DB is not ready");
				}
				CustomerBean customerBean = new CustomerBean();
				customerBean.setCustomerId(userBean.getCustomerId());
				customerBean.setAddress(request.getParameter("address"));
				customerBean.setMobile(request.getParameter("mobile"));
				
				boolean isDone = bankingService.updateDetails(customerBean);
				if (isDone) {
					request.setAttribute("msg","Customer Details updated ");
					view = "Pages/Success.jsp";
				} else {
					request.setAttribute("msg", "Record Not Found");
					view = "Pages/ErrorPage.jsp";
				}
			} catch (BankingException exp) {
				logger.error(exp);
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			
		case "/edit.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				view="Pages/Update.jsp";
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
			
		//-----------------------------------------------------------
		case "/admin.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");				
				HttpSession session=request.getSession(false);
				if(session.getAttribute("user").equals("Admin"))
					view="Pages/Admin.jsp";		
				else
					view="Pages/Login.jsp";
					
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
		break;
		case "/createAccount.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				HttpSession session=request.getSession(false);
				if(session.getAttribute("user").equals("Admin"))
					view="Pages/AddCustomer.jsp";		
				else
					view="Pages/Login.jsp";
			
				
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
		case "/addAccount.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				
				CustomerBean customer=new CustomerBean();
				customer.setCustomerName(request.getParameter("customerName"));
				customer.setEmail(request.getParameter("email"));
				customer.setMobile(request.getParameter("mobile"));
				customer.setAddress(request.getParameter("address"));
				customer.setPancard(request.getParameter("pancard"));
				List<AccountBean>accounts =new ArrayList<AccountBean>();
				if(request.getParameter("savings")!=null){
				AccountBean account= new AccountBean();
				account.setOpenDate(LocalDate.parse(request.getParameter("openDate")));
				account.setAccountType(request.getParameter("savings"));
				account.setAccountBalance(Double.parseDouble(request.getParameter("accountBalance")));
				accounts.add(account);
				}
				if(request.getParameter("current")!=null){
					AccountBean account= new AccountBean();
					account.setOpenDate(LocalDate.parse(request.getParameter("openDate")));
					account.setAccountType(request.getParameter("current"));
					account.setAccountBalance(Double.parseDouble(request.getParameter("accountBalance")));
					accounts.add(account);
					}
				
				customer.setAccounts(accounts);
				accounts=bankingService.addAccount(customer);
				if(accounts==null){
					view = "Pages/ErrorPage.jsp";
					request.setAttribute("msg","account cannot be added");
				}
				else{
					HttpSession session=request.getSession();
					session.setAttribute("accounts",accounts);					
					view= "Pages/AddCustomerSuccess.jsp";
					}
															
				
					
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
		
		case "/getUser.obj":
			try{
				if(bankingService==null)
					throw new BankingException("DB not Ready");
				UserBean userBean=bankingService.getUserCredentials(request.getParameter("accountId"));
				if(userBean!=null){
				System.out.println("");
				}
				
			}catch(BankingException exp){
				logger.error(exp);				
				request.setAttribute("msg", exp.getMessage());
				view = "Pages/ErrorPage.jsp";
			}
			break;
		}	
		RequestDispatcher rd = request.getRequestDispatcher(view);
		rd.forward(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}

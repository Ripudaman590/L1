package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class BankingServiceTest {
	
	private static BankingServices bankingServices;
	
	@BeforeClass
	public static void setUpBankingServices(){
		bankingServices = new BankingServicesImpl();
	}
	
	@Before
	public void setUpTestData ()
	{
		BankingDAOServicesImpl.customers.put(1000, new Customer(1000,"satish","mahajan","sm@capgi.com","ABCD1234","abcd",new Address(414141, "Pune", "Maharashtra"),new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(100, 0, "DEPOSIT"))));
		BankingDAOServicesImpl.customers.put(1001, new Customer(1001,"monica","dabas","md@capgi.com","ABASH234","tyrt",new Address(45645, "Gwalior", "Madhya Pradesh"),new Account(2, "CURRENT", 6000, 1234, "ACTIVE" , 0, new Transaction(101, 0, "WITHDRAW"))));
		BankingDAOServicesImpl.CUSTOMERS_ID_COUNTER =1001;
	}
		
	@Test(expected=CustomerNotFoundException.class)
	public void testAcceptCustomerDetailsForInvalidData() throws CustomerNotFoundException, BankingServicesDownException{

		bankingServices.getCustomerDetails(4545);

	}
	
	@Test
	public void testAcceptCustomerDetailsForValidData() throws CustomerNotFoundException, BankingServicesDownException{
		Customer expectedCustomer = new Customer(1000,"satish","mahajan","sm@capgi.com","ABCD1234","abcd","Pune",new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 1000, "DEPOSIT")));
		Customer actualCustomer = bankingServices.getCustomerDetails(1000);
		assertEquals(expectedCustomer, actualCustomer);
		
	}
	
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidData() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(-4545, "SAVINGS");
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidData1() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(4545, "CURRENT");
	}
	
	@Test
	public void testOpenAccountForValidData() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException{
		Account expectedAccount = new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 1000, "DEPOSIT"));
		Account actualAccount = bankingServices.getAccountDetails(1000, bankingServices.openAccount(5000, "SAVINGS"));
		assertEquals(expectedAccount,actualAccount );

	}
	
	
	@Test(expected=CustomerNotFoundException.class)
	public void testDepositAmountForInvalidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(0, 1, 500); 
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepositAmountForInvalidData1() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(1000, 5, 500); 
	}
	@Test(expected=InvalidAmountException.class)
	public void testDepositAmountForInvalidData2() throws CustomerNotFoundException,InvalidAmountException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException{
		bankingServices.depositAmount(1000, 1, -500); 
	}
	
	@Test
	public void testDepositAmountForValidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException
	{
		float expectedValue = 5500 ;
		float actaulValue = bankingServices.depositAmount(1000, 1, 500);
		assertEquals(expectedValue, actaulValue);
	}
	
	
	@Test(expected=CustomerNotFoundException.class)
	public void testWithdrawAmountForInvalidData() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(-14, 1, 5000, 1234);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testWithdrawAmountForInvalidData1() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(1000, 5, 5000, 1234);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testWithdrawAmountForInvalidData2() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(1000, 1, 4000, 1234);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testWithdrawAmountForInvalidData3() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.withdrawAmount(1000, 1, 5000, 4563);
	}
	
	
	@Test
	public void testWithdrawAmountForValidData() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException
	{
		float expectedValue = 4500;
		float actualValue = bankingServices.withdrawAmount(1000, 1, 500, 1234);
		assertEquals(expectedValue, actualValue);
	}
	
	
	@Test(expected=CustomerNotFoundException.class)
	public void testFundTransferForInvalidData() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.fundTransfer(1, 4554, 1, 787, 4545, 1234);
	}
	

	@Test(expected=AccountNotFoundException.class)
	public void testFundTransferForInvalidData1() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.fundTransfer(1001, 4554, 1000, 787, 4545, 1234);
	}
	
	@Test(expected=InsufficientAmountException.class)
	public void testFundTransferForInvalidData2() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.fundTransfer(1001, 2, 1000, 1, -4545, 1234);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testFundTransferForInvalidData3() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.fundTransfer(1001, 2, 1000, 1, 4545, 454);
		
	}
	
	@Test
	public void testFundTransferForValidData() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		boolean expectedValue= true;
		boolean actualValue= bankingServices.fundTransfer(1001, 2, 1000, 1, 100, 1234);
		assertEquals(expectedValue, actualValue);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerDetailsForInvalidData() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServices.getCustomerDetails(0);
		
	}
	
	@Test
	public void testGetCustomerDetailsForValidData() throws CustomerNotFoundException, BankingServicesDownException{
		Customer expectedCustomer = new Customer(1000,"satish","mahajan","sm@capgi.com","ABCD1234","abcd",new Address(414141, "Pune", "Maharashtra"),new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 0, "DEPOSIT")));
		Customer actualCustomer = bankingServices.getCustomerDetails(1000);
		assertEquals(expectedCustomer, actualCustomer);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testGetAccountDetailsForInvalidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.getAccountDetails(0, 0);
		
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidData1() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.getAccountDetails(0, 0);	
	}
	
	@Test
	public void testGetAccountDetailsForValidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Account expectedAccount = new Account(1, "SAVINGS", 5000, 1234, "ACTIVE" , 0, new Transaction(1, 0, "DEPOSIT"));
		Account actualAccount = bankingServices.getAccountDetails(1000, 1);
		assertEquals(expectedAccount, actualAccount);
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateCustomerAccountNewPin(0, 1);
	}
	

	@Test(expected=AccountNotFoundException.class)
	public void testGenerateCustomerAccountNewPinForInvalidData1() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateCustomerAccountNewPin(1000, 0);
	}
	
	@Test
	public void testGenerateCustomerAccountNewPinForValidData() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		int actualPin = bankingServices.generateCustomerAccountNewPin(1000, 1);
		int count = 0;
		if(actualPin!=0)
		{
			actualPin = actualPin/10;
			count++;
		}
		assertTrue(count == 4);
	}
	
	
	@Test(expected=CustomerNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidData() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.changeCustomerAccountPin(0, 1, 1234, 4567);
		
	}
	@Test(expected=AccountNotFoundException.class)
	public void testChangeCustomerAccountPinForInvalidData1() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.changeCustomerAccountPin(1000, 0, 1234, 4567);
		
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangeCustomerAccountPinForInvalidData2() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.changeCustomerAccountPin(1000, 1, 4578, 4567);
		
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangeCustomerAccountPinForInvalidData3() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		bankingServices.changeCustomerAccountPin(1000, 1, 4578, 12);
		
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testChangeCustomerAccountPinForValidData() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		
		Boolean expectedReturn = false;
		Boolean actualReturn = bankingServices.changeCustomerAccountPin(1000, 1, 1234, 4567);
		assertEquals(expectedReturn, actualReturn);
		
		
	}

	@Test
	public void testGetAllCustomerDetails() throws BankingServicesDownException{
		List<Customer> expectedCustomerList = new ArrayList<>(BankingDAOServicesImpl.customers.values());
		List<Customer> actualCustomerList = bankingServices.getAllCustomerDetails();
		assertEquals(expectedCustomerList, actualCustomerList);
		
	}

	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomerAllAccountDetailsForInvalidData() throws BankingServicesDownException, CustomerNotFoundException{
		bankingServices.getCustomerAllAccountDetails(0);
	}
	

	@Test
	public void testGetCustomerAllAccountDetailsForValidData() throws BankingServicesDownException, CustomerNotFoundException
	{
		List<Account> expectedAccountList = new ArrayList<>(BankingDAOServicesImpl.customers.get(1000).accounts.values());
		List<Account> actualAccountList = bankingServices.getCustomerAllAccountDetails(1000);
		assertEquals(expectedAccountList, actualAccountList);
		
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountAllTransactionForInvalid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getAccountAllTransaction(0);
	}
	
	@Test
	public void testGetAccountAllTransactionForValid() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		List<Transaction> expectedTransactionList = new ArrayList<>(BankingDAOServicesImpl.customers.get(1000).accounts.get(1).transactions.values());
		List<Transaction> actualTransactionList = bankingServices.getAccountAllTransaction(1);
		assertEquals(expectedTransactionList, actualTransactionList);
		
	}
	
	@Test(expected=CustomerNotFoundException.class)
	public void testGetCustomeAccountStatusForInvalidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getCustomeAccountStatus(0, 1);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testGetCustomeAccountStatusForInvalidData1() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getCustomeAccountStatus(1000, 0);
	}
	
	@Test
	public void testGetCustomeAccountStatusForValidData() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException
	{
		String expectedStatus = "ACTIVE";
		String actualStatus = bankingServices.getCustomeAccountStatus(1000, 1);
		assertEquals(expectedStatus, actualStatus);
		
	}
	
	
	
	@After
	public void tearDownTestData(){
	BankingDAOServicesImpl.customers.clear();
	BankingDAOServicesImpl.CUSTOMERS_ID_COUNTER =1000;
	}
	@AfterClass
	public static void tearDownBankingServices()
	{
		bankingServices = null;
	}

}

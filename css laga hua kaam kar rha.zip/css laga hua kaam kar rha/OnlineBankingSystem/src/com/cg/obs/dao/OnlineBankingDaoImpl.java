package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.cg.obs.dto.AccountBean;
import com.cg.obs.dto.CustomerBean;
import com.cg.obs.dto.ServiceTracker;
import com.cg.obs.dto.TransactionBean;
import com.cg.obs.dto.UserBean;
import com.cg.obs.exception.BankingException;
import com.cg.obs.util.DatasourceProvider;

public class OnlineBankingDaoImpl implements IOnlineBankingDao {
	
	public DataSource dataSource;	
	public OnlineBankingDaoImpl() throws BankingException {
		dataSource=DatasourceProvider.getDatasourceProvider().getDataSource();
	}
	/*
	 * (non-Javadoc)
	 * @see com.capgemini.onlinebanking.dao.IOnlineBankingDao#userLogin(java.lang.String, java.lang.String)
	 * Author: Yogesh Kumar Purohit
	 * Description: this function will check whether user is valid or not
	 * return: String 
	 * @throws Banking Exception
	 */
	@Override
	public UserBean userLogin(int userId)throws BankingException {
		UserBean userBean=null;
		if(userId!=0)
		{
			try(Connection con=dataSource.getConnection(); 
					PreparedStatement pstIns = con
							.prepareStatement(IQueryMapper.LOGIN_QRY)){
				pstIns.setInt(1, userId);
				ResultSet rst=pstIns.executeQuery();
				if(rst.next()){
					userBean=new UserBean();
					userBean.setCustomerId(rst.getString(1));
					userBean.setUserId(rst.getInt(2));
					userBean.setLoginPassword(rst.getString(3));
					userBean.setQuestion(rst.getString(4));
					userBean.setAnswer(rst.getString(5));
					userBean.setTransactionPassword(rst.getString(6));
					//t for lock f for unlock
					userBean.setLockStatus(rst.getString(7).charAt(0));
				}
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return userBean;
	}

	@Override
	public boolean lockUser(int userId) throws BankingException {
		boolean isDone=false;
		try(Connection con=dataSource.getConnection(); 
				PreparedStatement pstIns = con.prepareStatement(IQueryMapper.LOCK_QRY)){
			pstIns.setString(1,"T");
			pstIns.setInt(2,userId);
			int row=pstIns.executeUpdate();
			if(row!=0)
				isDone=true;
		}catch(SQLException exp){
			throw new BankingException(exp.getMessage());
		}
		return isDone;
	}
	
	@Override
	public boolean setUserSecurity(UserBean userBean) throws BankingException {
		boolean isDone=false;
		try(Connection con=dataSource.getConnection();
				PreparedStatement pstUserIns =con.prepareStatement
						(IQueryMapper.UPDATE_USER_SECURITY)){
			pstUserIns.setString(1, userBean.getQuestion());
			pstUserIns.setString(2, userBean.getAnswer());
			pstUserIns.setInt(3, userBean.getUserId());
			int rowCount=pstUserIns.executeUpdate();
			if(rowCount>0)
				isDone=true;
		}catch(SQLException exp){
			throw new BankingException(exp.getMessage());}
		return isDone;
	}
	
	//new 
	@Override
	public List<TransactionBean> getMiniStatementsById(String accountId) throws BankingException{
		
		List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
		if(accountId!=null){
			int count=0;
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstMini=con.prepareStatement(IQueryMapper.GET_MINISTATEMENT)){
				pstMini.setString(1, accountId);
				ResultSet rst=pstMini.executeQuery();
				while(rst.next() && count<10){
					TransactionBean transactionBean=new TransactionBean();
					transactionBean.setTransactionId(rst.getString(1));
					transactionBean.setTransactionDate(rst.getDate(2).toLocalDate());
					transactionBean.setTransactionAmount(rst.getDouble(3));
					transactionList.add(transactionBean);
					count++;
				}
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return transactionList;
	}
	//new

	@Override
	public List<TransactionBean> getTransactionByAccId(String from,String to)throws BankingException {

		List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
		if( from!=null && to!=null){
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstMini=con.prepareStatement(IQueryMapper.GET_TRANSACTION)){
				
				pstMini.setDate(1, Date.valueOf(from));
				pstMini.setDate(2, Date.valueOf(to));
				ResultSet rst=pstMini.executeQuery();
				while(rst.next()){
					TransactionBean transactionBean=new TransactionBean();
					transactionBean.setTransactionId(rst.getString(1));
					transactionBean.setTransactionDesc(rst.getString(2));
					transactionBean.setTransactionDate(rst.getDate(3).toLocalDate());
					transactionBean.setTransactionType(rst.getString(4));
					
					transactionBean.setTransactionAmount(rst.getDouble(5));
					transactionBean.setAccountId(rst.getString(6));
					transactionList.add(transactionBean);
				}
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return transactionList;
	}
	//new
	@Override
	public Integer[] getAccountId(String customerId ) throws BankingException{

		Integer accIds[]=new Integer[2];
		if(customerId!=null){
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstCusIns=con.prepareStatement
							(IQueryMapper.GET_ACCOUNTID_QRY)){
			
				pstCusIns.setString(1, customerId);
				ResultSet rs=pstCusIns.executeQuery();
				int i=0;
				while(rs.next()){
					accIds[i]= rs.getInt(1);
					i++;
					
				}					
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return accIds;		
	}
	
	@Override
	public CustomerBean getCustomerDetails(int customerId) throws BankingException{
		CustomerBean customerBean=null;
		if(customerId!=0){
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstCusIns=con.prepareStatement
							(IQueryMapper.GET_CUSTOMER_QRY)){
				pstCusIns.setInt(1, customerId);
				ResultSet rs=pstCusIns.executeQuery();
				if(rs.next()){
					customerBean=new CustomerBean();
					customerBean.setCustomerId(rs.getString(1));
					customerBean.setCustomerName(rs.getString(2));
					customerBean.setEmail(rs.getString(3));
					customerBean.setAddress(rs.getString(4));
					customerBean.setPancard(rs.getString(5));
					customerBean.setMobile(rs.getString(6));
					Integer[] accountIds=getAccountId(customerBean.getCustomerId());
					int i=0;
					List<AccountBean> accounts=new ArrayList<AccountBean>();
					while(i<accountIds.length){
						accounts.add(getAccountDetails(accountIds[i]));
						i++;
					}
					customerBean.setAccounts(accounts);
				}					
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return customerBean;		
	}
	
	
	/*
	 * ----------------------------------------------------------
	 * */
	
	//new
	@Override
	 public CustomerBean addCustomer(CustomerBean customer) throws BankingException{
		CustomerBean customerBean=null;
		if(customer!=null){
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstCusIns=con.prepareStatement
							(IQueryMapper.INSERT_CUSTOMER_QRY)){
				int rowCount=0;
				pstCusIns.setString(1, customer.getCustomerName());
				pstCusIns.setString(2, customer.getEmail());
				pstCusIns.setString(3, customer.getAddress());
				pstCusIns.setString(4, customer.getPancard());
				pstCusIns.setString(5, customer.getMobile());
				rowCount=pstCusIns.executeUpdate();
				if(rowCount>0)
					customerBean=customer;
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
			
		}
		return customerBean;
	}
	
	@Override
	public List<AccountBean> addAccount(CustomerBean customer) throws BankingException {
		List<AccountBean> accountList=new ArrayList<AccountBean>();
		if(customer!=null){
			
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstAccIns =con.prepareStatement
							(IQueryMapper.INSERT_ACCOUNT_QRY);					
					PreparedStatement pstCusAccIns=con.prepareStatement
							(IQueryMapper.INSERT_CUST_ACC);
					PreparedStatement pstAccSel=con.prepareStatement
							(IQueryMapper.SELECT_ACCOUNT_ID_QRY)){
				int rowCount=0;							
					for(AccountBean account: customer.getAccounts()){

						pstAccIns.setString(1, account.getAccountType());
						pstAccIns.setDouble(2, account.getAccountBalance());
						pstAccIns.setDate(3, Date.valueOf(account.getOpenDate()));
						rowCount=pstAccIns.executeUpdate();
						if(rowCount>0)
						{
							ResultSet res=pstAccSel.executeQuery();
							if(res.next()){
								account.setAccountId(res.getString(1));
								accountList.add(account);								
								rowCount =pstCusAccIns.executeUpdate();
								if(rowCount==0)
									throw new BankingException("Error inserting data");
							}			
						}
					
				}						
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
			
		}
		
		return accountList;
	}
	
	
	
//new
	@Override
	public boolean setUserCredentials() throws BankingException {
		boolean isDone=false;	
			
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstUserIns =con.prepareStatement
							(IQueryMapper.INSERT_USER_QRY)){				
				int rowCount=pstUserIns.executeUpdate();
				if(rowCount>0)
					isDone=true;
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}		
					
		return isDone;
	}

	//new
	@Override
	public UserBean getUserCredentials(String accountId)
			throws BankingException {
			UserBean userBean=null;
		if(accountId!=null){
			
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstUserSel =con.prepareStatement
							(IQueryMapper.SELECT_USER_CRED_QRY)){
				pstUserSel.setString(1,accountId);				
				ResultSet res=pstUserSel.executeQuery();
				if(res.next()){
					userBean=new UserBean();
					userBean.setCustomerId(res.getString(1));
					userBean.setUserId(res.getInt(2));
					userBean.setLoginPassword(res.getString(3));
					userBean.setQuestion(res.getString(4));
					userBean.setAnswer(res.getString(5));
					userBean.setTransactionPassword(res.getString(6));
					userBean.setLockStatus(res.getString(7).charAt(0));
				}
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}

			}
		return userBean;
	}
	
	@Override
	public AccountBean getAccountDetails(int accountId) throws BankingException{
		
		AccountBean accountBean=null;
		if(accountId!=0){
			try(Connection con=dataSource.getConnection();
					PreparedStatement pstCusIns=con.prepareStatement
							(IQueryMapper.GET_ACCOUNT_QRY)){
			
				pstCusIns.setInt(1, accountId);
				ResultSet rs=pstCusIns.executeQuery();
				
				if(rs.next()){
					accountBean=new AccountBean();
					accountBean.setAccountId(rs.getString(1));
					accountBean.setAccountType(rs.getString(2));
					accountBean.setAccountBalance(rs.getDouble(3));;
					accountBean.setOpenDate(rs.getDate(4).toLocalDate());
				}					
			}catch(SQLException exp){
				throw new BankingException(exp.getMessage());
			}
		}
		return accountBean;
	}
	
	@Override
	public boolean requestChequeBook(String accountId) throws BankingException {
		boolean isDone=false;
		try(Connection conn=dataSource.getConnection();
				PreparedStatement pstChq = conn.prepareStatement(IQueryMapper.INSERT_SERVICE_CHQ)) {
			pstChq.setString(1, accountId);
			int row=pstChq.executeUpdate();
			
			if(row>0)
			{
				isDone=true;
			}
			
		} catch (SQLException exp) {
			throw new BankingException(exp.getMessage());
		}
		return isDone;
	}
	
	@Override
	public boolean changePassword(String userId, String newPassword) throws BankingException {
		boolean isDone=false;
		try(Connection conn=dataSource.getConnection();
				PreparedStatement pstPass = conn.prepareStatement(IQueryMapper.CHANGE_PASSWORD)) {
			pstPass.setString(1, newPassword);
			pstPass.setString(2, userId);
			int row=pstPass.executeUpdate();
			
			if(row>0)
			{
				isDone=true;
			}
			
		} catch (SQLException exp) {
			throw new BankingException(exp.getMessage());
		}
		return isDone;
	}
	
	//new
	@Override
	public boolean updateDetails(CustomerBean customerBean) throws BankingException {
		boolean isDone = false;
		if (customerBean != null) {
			try (Connection con = dataSource.getConnection();
					PreparedStatement pstUpd = con
							.prepareStatement(IQueryMapper.UPDATE_DETAILS_QRY);) {
				pstUpd.setString(1, customerBean.getAddress());
				pstUpd.setString(2, customerBean.getMobile());
				pstUpd.setString(3, customerBean.getCustomerId());
				
				int rowCount = pstUpd.executeUpdate();

				if (rowCount > 0) {
					isDone = true;
				}

			} catch (SQLException exp) {
				throw new BankingException(exp.getMessage());
			}
		}
		return isDone;
	}
	@Override
	public ServiceTracker requestStatus(String serviceId) throws BankingException {
		System.out.println(serviceId);
		//int a = serviceId;
		ServiceTracker myServiceTracker = new ServiceTracker();
		myServiceTracker.setServiceId(serviceId);
		String query="SELECT serviceStatus FROM servicetracker WHERE serviceId=?";
		try
		{
		Connection con = dataSource.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1,myServiceTracker.getServiceId());
		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			ServiceTracker myServiceTracker2 = new ServiceTracker();
		 myServiceTracker2.setStatus(rs.getString(1));
		 return myServiceTracker2;
		}
		else
		{
			return null;
		}
		}
		catch(SQLException e)
		{
				throw new BankingException(e.getMessage());
		}
	}
	/*@Override
	boolean updateAccBalance(double transAmount, String accountId) throws BankingException(){
		boolean isDone = false;
		if (transactionBean != null) {
			try (Connection con = dataSource.getConnection();
					PreparedStatement pstUpd = con
							.prepareStatement(IQueryMapper.UPDATE_ACCBALANCE_QRY);) {
				pstUpd.setDouble(1,transAmount);
				
				int rowCount = pstUpd.executeUpdate();

				if (rowCount > 0) {
					isDone = true;
				}

			} catch (SQLException exp) {
				throw new BankingException(exp.getMessage());
			}
		}
		return isDone;
		
	}*/
	
	@Override
	public boolean updateAccBalance(double transAmount, String accountId)
			throws BankingException {
		boolean isDone = false;
		int rowCount;
		
			try{
				Connection con = dataSource.getConnection();
			    PreparedStatement pstUpd = con
							.prepareStatement(IQueryMapper.UPDATE_FROMACCBALANCE_QRY);
				    pstUpd.setDouble(1,transAmount);
				    pstUpd.setString(2,accountId);
				    rowCount = pstUpd.executeUpdate();

				PreparedStatement pstUpd2 = con
						.prepareStatement(IQueryMapper.UPDATE_TOACCBALANCE_QRY);
		        	pstUpd2.setDouble(1,transAmount);
		         	pstUpd2.setString(2,accountId);
			        rowCount = pstUpd.executeUpdate();
			
			        if (rowCount > 0) {
					isDone = true;
				}

			} catch (SQLException exp) {
				throw new BankingException(exp.getMessage());
			}
		
		return isDone;
		
		
	}
}
		
	/*@Override
	public List<TransactionBean> getTransactionByOnlyAccID(String accountId) {
		
		return null;
	}*/


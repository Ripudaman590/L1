package com.cg.mobilebilling.beans;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Customer {
	private int customerID;
	private String firstName, lastName, emailID, dateOfBirth,password;
	private List<Address> address;
	private Map<Long, PostpaidAccount> postpaidAccounts = new HashMap<>();
}
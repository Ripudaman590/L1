package com.capgemini.payroll.services;
import java.sql.SQLException;
import java.util.List;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.beans.BankDetails;
import com.capgemini.payroll.beans.Salary;
import com.capgemini.payroll.daoservices.PayrollDAOServices;
import com.capgemini.payroll.daoservices.PayrollDAOServicesImpl;
import com.capgemini.payroll.exception.AssociateDetailsNotFoundException;
import com.capgemini.payroll.exception.PayrollServicesDownException;
import com.capgemini.payroll.provider.ServiceProvider;

public class PayrollServicesImpl implements PayrollServices{
	private PayrollDAOServices daoServices;
	
	public PayrollServicesImpl() {
		daoServices = new PayrollDAOServicesImpl();
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailID, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int companyPf, int epf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws PayrollServicesDownException, AssociateDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean removeAssociate(int associateId) throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	
}
